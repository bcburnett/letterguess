import {LitElement, html, css} from 'lit-element';
import {connect} from 'pwa-helpers/connect-mixin.js';
import {store} from '../redux/store.js';

/**
 *
 *
 * @export
 * @class BcbGameKeyboard
 * @augments {connect(store)(LitElement)}
 */
export class BcbGameKeyboard extends connect(store)(LitElement) {
  /**
   *
   * lit-element observed properties
   * @readonly
   * @static
   * @memberof BcbGameKeyboard
   */
  static get properties() {
    return {

    };
  }


  /**
   *
   * lit-element styles array. external style sheets can be added here.
   * @readonly
   * @static
   * @memberof BcbGameKeyboard
   */
  static get styles() {
    return [css`
button{
  padding-top:4px;
  background-color:rgba(255, 255, 255,.75);
  color:var(--calc-color);
  border-color:var(--calc-color);
  border-width:1px;
  font-weight: bold;
  font-size:1rem;
}

button:hover{
  color:orange;
  background-color:lightblue;
  scale:1.2;
}

.keyboard{
  width:33%;
  padding-top:8px;
  display:grid;
  grid-template-columns: 1fr 1fr 1fr 1fr;
  grid-gap:3px;
  margin: auto;
}

.orange{
  color:orange;
}

@media (max-width: 800px) {
  .keyboard{
    width: 90%;
  }
  button{
    font-size: 1rem;
  }
}
`];
  }


  /**
   * renders this custom elements html and css
   *
   * @return {object} renders this custom elements html and css
   * @memberof BcbGameKeyboard
   */
  render() {
    const makeButtons = () => {
      return this.btnArray.map((e) => html`
          <button
          @click="${(e) => this.buttonClick(e.path[0].id)}"
          id="${e}"
          >
          ${e}
        </button>
        `);
    };
    return html`
    <div class="keyboard">
      ${makeButtons()}
    </div>
    `;
  }

  /**
   *
   *
   * @param {string} btn
   * @memberof BcbGameKeyboard
   */
  buttonClick(btn) {
    this.dispatchEvent(new CustomEvent('bcbcgamekeyboard', {detail: btn}));
  }

  /**
   * run on state change
   *
   * @param {object} state read only.
   * @memberof BcbGameKeyboard
   */
  stateChanged(state) {
    console.log(state.hangman.guesses.length);
    const app = state.hangman;
    if (app.guesses.length === 0 && this.shadowRoot.getElementById('A')) {this.btnArray.forEach(e => {
      const element = this.shadowRoot.getElementById(e);
      element.classList.remove('orange');
    });}
    app.guesses.forEach((e) => {
      const element = this.shadowRoot.getElementById(e);
      element.classList.add('orange');
    });
    this.btnArray = app.btnArray;
  }
}

customElements.define('bcb-game-keyboard', BcbGameKeyboard);
